document.addEventListener('DOMContentLoaded', () => {
    const itemsTable = document.getElementById('itemsTable');

    if (itemsTable) {
        const fetchItems = async () => {
            try {
                const response = await fetch('/items');
                const items = await response.json();
                const tbody = itemsTable.querySelector('tbody');
                tbody.innerHTML = '';
                items.forEach(item => {
                    const row = tbody.insertRow();
                    row.innerHTML = `
                        <td>${item.id}</td>
                        <td>${item.name}</td>
                        <td>${item.quantity}</td>
                        <td>${item.price}</td>
                        <td>
                            <button onclick="editItem(${item.id})">Edit</button>
                            <button onclick="deleteItem(${item.id})">Delete</button>
                        </td>
                    `;
                });
            } catch (error) {
                console.error('Error fetching items:', error);
            }
        };

        fetchItems();
    } else {
        console.error('Items table not found in the DOM.');
    }
});
